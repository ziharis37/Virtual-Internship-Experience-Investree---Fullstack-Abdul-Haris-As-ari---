<!DOCTYPE html>
<html lang="en">
<head>
    <title>CRUD L8 <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<h2> Tutorial CRUD Laravel</h2>

<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\laragon\www\contohCRUD\resources\views/layouts/layout.blade.php ENDPATH**/ ?>