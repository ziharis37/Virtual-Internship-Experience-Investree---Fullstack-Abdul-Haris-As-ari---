

<?php $__env->startSection('title'); ?>
Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(url('input')); ?>">Tambah Data</a>
    <table border="2" width="50%">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>No Telepon</th>
            <th>Action</th>
        </tr>

        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->alamat); ?></td>
            <td><?php echo e($data->no_telp); ?></td>

            <td>
                <a href="/<?php echo e($data->id); ?>/edit">Edit</a>
               
                <form method="POST" action="/<?php echo e($data->id); ?>/delete">
                <?php echo csrf_field(); ?>
                <!-- <?php echo e(csrf_field()); ?> -->
                <input type="submit" name="delete" value="Delete"/>

                    <input type="hidden" name="_method" value="DELETE"/>

                </form>


                <!-- <a href="">Delete</a> -->
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\contohCRUD\resources\views/table.blade.php ENDPATH**/ ?>