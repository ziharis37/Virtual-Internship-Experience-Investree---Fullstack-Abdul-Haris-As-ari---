

<?php $__env->startSection('title'); ?>
Input
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="/<?php echo e($siswa_data->id); ?>edit">
    <?php echo e(csrf_field()); ?>

    <table>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="var_nama" placeholder="Nama" value="<?php echo e($siswa_data->nama); ?>"/></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><textarea name="alamat"><?php echo e($siswa_data->alamat); ?></textarea></td>
        </tr>
        <tr>
            <td>No Telepon</td>
            <td><input type="text" name="no_telp" placeholder="08xxxx" value="<?php echo e($siswa_data->no_telp); ?>"/></td>
        </tr>
        <tr>
            <td></td>
            <td><input name="submit" type="submit"  value="submit"/></td>
        </tr>
    </table>
    <input type="hidden" name="_method" value="PUT">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\contohCRUD\resources\views/edit.blade.php ENDPATH**/ ?>