

<?php $__env->startSection('title'); ?>
Input
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="/input">
    <?php echo e(csrf_field()); ?>

    <table>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="var_nama" placeholder="Nama"/></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><textarea name="alamat"></textarea></td>
        </tr>
        <tr>
            <td>No Telepon</td>
            <td><input type="text" name="no_telp" placeholder="08xxxx"/></td>
        </tr>
        <tr>
            <td></td>
            <td><input name="submit" type="submit"  value="submit"/></td>
        </tr>
    </table>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\contohCRUD\resources\views/input.blade.php ENDPATH**/ ?>