<!DOCTYPE html>
<html lang="en">
<head>
        <title>Home</title>
</head>
<body>
    <h1>Selamat Datang di CRUD by Haris</h1>
    <a href="table">klik untuk buka table</a>
</body>
</html><?php /**PATH C:\laragon\www\contohCRUD\resources\views/home.blade.php ENDPATH**/ ?>