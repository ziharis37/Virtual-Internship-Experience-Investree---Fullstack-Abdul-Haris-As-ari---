@extends('layouts.layout')

@section('title')
Table
@endsection

@section('content')

<a href="{{ url('input') }}">Tambah Data</a>
    <table border="2" width="50%">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>No Telepon</th>
            <th>Action</th>
        </tr>

        @foreach($siswa as $data)
        <tr>
            <td>{{$no++}}</td>
            <td>{{$data->nama}}</td>
            <td>{{$data->alamat}}</td>
            <td>{{$data->no_telp}}</td>

            <td>
                <a href="/{{$data->id}}/edit">Edit</a>
               
                <form method="POST" action="/{{$data->id}}/delete">
                @csrf
                <!-- {{ csrf_field() }} -->
                <input type="submit" name="delete" value="Delete"/>

                    <input type="hidden" name="_method" value="DELETE"/>

                </form>


                <!-- <a href="">Delete</a> -->
            </td>
        </tr>
        @endforeach
    </table>
@endsection
