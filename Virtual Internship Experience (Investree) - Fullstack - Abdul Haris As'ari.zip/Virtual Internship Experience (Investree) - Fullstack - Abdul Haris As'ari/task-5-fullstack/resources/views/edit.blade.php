@extends('layouts.layout')

@section('title')
Input
@endsection

@section('content')

<form method="POST" action="/{{$siswa_data->id}}edit">
    {{csrf_field()}}
    <table>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="var_nama" placeholder="Nama" value="{{ $siswa_data->nama}}"/></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><textarea name="alamat">{{$siswa_data->alamat}}</textarea></td>
        </tr>
        <tr>
            <td>No Telepon</td>
            <td><input type="text" name="no_telp" placeholder="08xxxx" value="{{ $siswa_data->no_telp}}"/></td>
        </tr>
        <tr>
            <td></td>
            <td><input name="submit" type="submit"  value="submit"/></td>
        </tr>
    </table>
    <input type="hidden" name="_method" value="PUT">
</form>
@endsection
