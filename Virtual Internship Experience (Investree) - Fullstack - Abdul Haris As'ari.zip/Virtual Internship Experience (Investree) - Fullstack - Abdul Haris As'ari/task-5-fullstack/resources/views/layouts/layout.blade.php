<!DOCTYPE html>
<html lang="en">
<head>
    <title>CRUD L8 @yield('title')</title>
</head>
<body>
<h2> Tutorial CRUD Laravel</h2>

@yield('content')
</body>
</html>