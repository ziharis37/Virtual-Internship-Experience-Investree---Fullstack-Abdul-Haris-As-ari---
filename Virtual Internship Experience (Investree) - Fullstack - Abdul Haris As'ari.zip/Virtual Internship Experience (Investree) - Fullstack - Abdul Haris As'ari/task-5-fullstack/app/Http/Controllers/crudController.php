<?php

namespace App\Http\Controllers;

use App\Models\siswa as ModelsSiswa;
use Illuminate\Http\Request;
use App\Models\siswa;


class crudController extends Controller
{
    function input()
    {
        return view('input');  
    }

    function edit($id)
    {
        $siswa = siswa::where('id','=',$id)->first();

        return view('edit')  
        ->with('siswa_data',$siswa);
    }

    function update(Request $request, $id)
    {
        $siswa = siswa::find($id);

            $siswa->nama = $request->var_nama;
            $siswa->alamat = $request->alamat;
            $siswa->no_telp = $request->no_telp;
            
        $siswa->save();
        return redirect('/table');  
    }

    function table()
    {
        $siswa = siswa::all();
        return view('table')
        ->with('siswa',$siswa)
        ->with('no',1); 
         
    }


    function insert(Request $request)
    {
        $siswa = new siswa;

            $siswa->nama = $request->var_nama;
            $siswa->alamat = $request->alamat;
            $siswa->no_telp = $request->no_telp;
            
        $siswa->save();
        return redirect('/table');  
    }

    function delete($id){
        $siswa = siswa::find($id);
        $siswa->delete();

        return redirect('/table');  
    } 
}
